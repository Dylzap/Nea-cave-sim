﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaveRescue
{
    public partial class Addobjectfrm : Form
    {
        public Cavedesigner cavedesigner;

        public Addobjectfrm(Cavedesigner cavedesigner)
        {
            InitializeComponent();
            this.cavedesigner = cavedesigner;

        }

        public Addobjectfrm()
        {
        }

        private void btn_makenewobject_Click(object sender, EventArgs e)
        {
            string newItem = txt_nameofobject.Text.Trim();

            if (!string.IsNullOrEmpty(newItem))
            {
                if (int.TryParse(txt_weightofobject.Text.Trim(), out int associatedValue))
                {
                    cavedesigner.AddItemToComboBox(newItem, associatedValue);
                    MessageBox.Show("Item added to ComboBox on Form1");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please enter a valid integer for the associated value.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid item.");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Colourdialog colour = new Colourdialog();
            colour.ShowDialog();
        }
    }
}
