﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaveRescue
{
    public class Itemwithweighting
    {
        public string Item { get; set; }
        public int AssociatedValue { get; set; }

        public Itemwithweighting(string Object, int Weighting)
        {
            Item = Object;
            AssociatedValue = Weighting;
        }

        public override string ToString()
        {
            return Item; // Display the item as a string in the ComboBox
        }
    }
}
