﻿namespace CaveRescue
{
    partial class Addobjectfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nameofobject = new System.Windows.Forms.Label();
            this.lbl_weightofobject = new System.Windows.Forms.Label();
            this.txt_nameofobject = new System.Windows.Forms.TextBox();
            this.txt_weightofobject = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_makenewobject = new System.Windows.Forms.Button();
            this.Colourdialog = new System.Windows.Forms.ColorDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_nameofobject
            // 
            this.lbl_nameofobject.AutoSize = true;
            this.lbl_nameofobject.Location = new System.Drawing.Point(35, 144);
            this.lbl_nameofobject.Name = "lbl_nameofobject";
            this.lbl_nameofobject.Size = new System.Drawing.Size(82, 13);
            this.lbl_nameofobject.TabIndex = 0;
            this.lbl_nameofobject.Text = "Name of object:";
            // 
            // lbl_weightofobject
            // 
            this.lbl_weightofobject.AutoSize = true;
            this.lbl_weightofobject.Location = new System.Drawing.Point(35, 221);
            this.lbl_weightofobject.Name = "lbl_weightofobject";
            this.lbl_weightofobject.Size = new System.Drawing.Size(88, 13);
            this.lbl_weightofobject.TabIndex = 1;
            this.lbl_weightofobject.Text = "Weight of object:";
            // 
            // txt_nameofobject
            // 
            this.txt_nameofobject.Location = new System.Drawing.Point(163, 141);
            this.txt_nameofobject.Name = "txt_nameofobject";
            this.txt_nameofobject.Size = new System.Drawing.Size(161, 20);
            this.txt_nameofobject.TabIndex = 2;
            // 
            // txt_weightofobject
            // 
            this.txt_weightofobject.Location = new System.Drawing.Point(163, 214);
            this.txt_weightofobject.Name = "txt_weightofobject";
            this.txt_weightofobject.Size = new System.Drawing.Size(161, 20);
            this.txt_weightofobject.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(160, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Make your own object";
            // 
            // btn_makenewobject
            // 
            this.btn_makenewobject.Location = new System.Drawing.Point(163, 315);
            this.btn_makenewobject.Name = "btn_makenewobject";
            this.btn_makenewobject.Size = new System.Drawing.Size(109, 23);
            this.btn_makenewobject.TabIndex = 7;
            this.btn_makenewobject.Text = "Make the new object";
            this.btn_makenewobject.UseVisualStyleBackColor = true;
            this.btn_makenewobject.Click += new System.EventHandler(this.btn_makenewobject_Click);
            // 
            // Colourdialog
            // 
            this.Colourdialog.AnyColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(393, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Select colour ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Addobjectfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 392);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_makenewobject);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_weightofobject);
            this.Controls.Add(this.txt_nameofobject);
            this.Controls.Add(this.lbl_weightofobject);
            this.Controls.Add(this.lbl_nameofobject);
            this.Name = "Addobjectfrm";
            this.Text = "Add the weight of the object";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nameofobject;
        private System.Windows.Forms.Label lbl_weightofobject;
        private System.Windows.Forms.TextBox txt_nameofobject;
        private System.Windows.Forms.TextBox txt_weightofobject;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_makenewobject;
        private System.Windows.Forms.ColorDialog Colourdialog;
        private System.Windows.Forms.Button button1;
    }
}