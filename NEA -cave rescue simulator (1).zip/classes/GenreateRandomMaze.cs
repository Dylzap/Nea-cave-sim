﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NEA__cave_rescue_simulator
{
    public class GenreateRandomMaze 
    {
       
        
        
      

    }
}
