﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace NEA__cave_rescue_simulator
{
    public class GridSpace : Panel
    {
        public const int GRID_SPACE_WIDTH = 20;
        public const int GRID_SPACE_HEIGHT = 20;

        public int X { get; }
        public int Y { get; }
        public GridSpace Parent { get; set; }
        public int G { get; set; } // cost to ending point
        public int H { get; set; } // cost from starting point

        public GridSpace(int x, int y)
        {
            X = x;
            Y = y;
            G = 0;
            H = 0;
            Parent = null;
        }

        public int F
        {
            get { return G + H; }
        }

        public int GridX = 0;
        public int GridY = 0;

        public bool isSelected = false;   
        public bool iswall {get; set;}

        public GridSpace()
        {
            this.AutoSize = false;
            this.BorderStyle = BorderStyle.FixedSingle;
        }

        public void Cellclickedon()
        {    
                this.BorderStyle = BorderStyle.Fixed3D;
                this.BackColor = Color.Yellow;
                this.Text = "C";
                isSelected = true;         
        }
        public void Deselectcell()
        {
            //Deselect
            this.BorderStyle = BorderStyle.FixedSingle;
            this.BackColor = Color.White;
            this.Text = "";
            isSelected = false;


        }

        public void Highlightcell()
        {
            this.BackColor = Color.Yellow;
            this.BorderStyle = BorderStyle.FixedSingle;
        }

    }
}
